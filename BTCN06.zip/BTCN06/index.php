<?php 
  require_once 'init.php';
  require_once 'functions.php';
?>
<?php include 'header.php'; ?>
<h1>Chào mừng các bạn đến với môn Web 1</h1>
<?php include 'footer.php'; ?>
